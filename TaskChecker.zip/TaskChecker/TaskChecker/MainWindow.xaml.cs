﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using TaskChecker;

namespace TaskChecker
{
    /// <summary>
    /// Логика взаимодействия для MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
            PrefomanceCounter();
        }
        public class Process
        {
            public int Number { get; set; }
            public string title { get; set; }
            public string usage { get; set; }
            public SolidColorBrush Color { get; set; }

        }
        public void PrefomanceCounter()
        {
            System.Diagnostics.Process[] myProcs = System.Diagnostics.Process.GetProcesses();
            var sorted = myProcs.OrderBy(p => p.UserProcessorTime);
            StringBuilder sb = new StringBuilder();
            List<Process> list = new List<Process>();

            int i = 1;

            foreach (var proc in myProcs)
            {
                if (i < 5)
                {
                    var cpuCounter = new PerformanceCounter("Processor", "% Processor Time", "_Total");

                    cpuCounter.NextValue().ToString();
                    System.Threading.Thread.Sleep(1000);

                    SolidColorBrush color;
                    float usageValue = cpuCounter.NextValue();
                    if (usageValue > 15)
                    {
                        color = Brushes.Red;
                    }
                    else if (usageValue > 10)
                    {
                        color = Brushes.Yellow;
                    }
                    else 
                    {
                        color = Brushes.Green;
                    }


                    list.Add(new Process
                    {
                        Number = i,
                        title = proc.ProcessName,
                        usage = usageValue.ToString() + "%",
                        Color = color
                    });
                    i++;
                }
                else
                {
                    break;
                }
            }
            list.OrderBy(x => x.usage);
            dg.ItemsSource = new ListCollectionView(list);

        }
        private void Update(object sender, RoutedEventArgs e)
        {
            dg.ItemsSource = null;
            PrefomanceCounter();
        }
       

    }
}
